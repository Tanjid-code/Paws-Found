<?php

include './partials/header.php';

?>

<!-- ##################################### About page ####################################### -->
<section class="container">
  <div class="about-container">
    <h2 class="line">About</h2>

    <div class="box-container">
      <div class="box1 box">
        <img src="./static-images/a.png" alt="" />
      </div>
      <div class="box2 box">
        <h3>About Blog</h3>
        <p class="about-blog">
       
The pet adoption website is a dynamic online platform that connects potential pet adopters with animals in need of a loving home. It offers a user-friendly interface where users can browse profiles of adoptable pets, complete with photos, descriptions, and adoption requirements. With features such as customizable search filters by breed, age, and location, the site helps users find pets that match their preferences and lifestyle.<br>

The application typically includes functionalities like user registration, adoption request forms, and communication tools to facilitate interactions between adopters and shelters or foster families. Through an intuitive content management system, administrators can easily manage pet profiles, track inquiries, and update the site's content to keep it fresh and engaging. Social media sharing options and pet care resources are often integrated to increase outreach, awareness, and support among the community. 
      </div>
    </div>
  </div>
</section>



<?php 

include './partials/footer.php';
?>
