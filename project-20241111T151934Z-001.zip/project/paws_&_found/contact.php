<?php 
include './partials/header.php';
?>


    <!-- ##################################### About page ####################################### -->



    <section class="container">
    <div class="contact-page">
        <h2>Contact US</h2>
        <form action="" enctype="multipart/form-data" class="contact-us">
            <input type="text" placeholder="Full Name">
            <input type="text" placeholder="Subject">
            <input type="email" placeholder="Email">
            <textarea name="" id="" cols="30" rows="10" placeholder="Message"></textarea>
            <button type="submit" class="btn">Send Message</button>
        </form>
    </div>
</section>






   
<?php 
include './partials/footer.php';
?>