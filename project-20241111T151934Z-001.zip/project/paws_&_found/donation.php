<?php
include './partials/header.php';
?>

<section class="donation">
<div class="container">
      <h1>Help Support Homeless Pets</h1>
      <p class="intro-text">
        Your donation will go directly towards medical care, food, and shelter
        for pets in need. Join us in making a difference!
      </p>

      <div class="donation-options">
        <div class="donation-option d1">
          <h2>৳500</h2>
          <p>Provides food for one week for a pet.</p>
          <button class="btn">Donate ৳500</button>
        </div>
        <div class="donation-option d2">
          <h2>৳2000</h2>
          <p>Covers a health check-up for a rescued pet.</p>
          <button class="btn">Donate ৳2000</button>
        </div>
        <div class="donation-option d3">
          <h2>৳5000</h2>
          <p>Supports emergency medical care for injured animals.</p>
          <button class="btn">Donate ৳5000</button>
        </div>
      </div>

      <div class="donation-form">
        <h2>Custom Donation</h2>
        <form action="" method="POST">
          <label for="amount">Donation Amount (৳)</label>
          <input type="number" id="amount" name="amount" min="1" required />

          <label for="name">Full Name</label>
          <input type="text" id="name" name="name" required />

          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" required />

          <label for="payment-method">Payment Method</label>
          <select id="payment-method" name="payment-method" required>
            <option value="bkash">bKash</option>
            <option value="nogad">Nagad</option>
            <option value="rocket">Rocket</option>
          </select>

          <a href="thanks.php" type="submit" class="btn">Donate Now</a>
        </form>
      </div>
    </div>
</section>

<?php
include './partials/footer.php';
?>