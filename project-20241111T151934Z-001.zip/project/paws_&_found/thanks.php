<?php
include './partials/header.php';
?>

<section class="thanks">
<div class="container">
      <h1>Thank You!</h1>
      <div class="message">
        <p>
          Your generous donation has made a real difference in the lives of
          homeless pets. <br /><br />
          Because of <span class="highlight">your kindness</span>, injured
          animals can receive medical care, and abandoned pets can find loving
          homes.
        </p>
        <p>
          Every act of kindness, big or small, helps build a brighter future for
          these animals. You are a true hero to them, and we are incredibly
          grateful for your support.
        </p>
      </div>
      <a href="index.php" class="btn">Return to Home</a>
    </div>
</section>



<?php
include './partials/footer.php';
?>