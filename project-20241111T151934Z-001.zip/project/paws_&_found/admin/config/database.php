<?php
require 'constants.php';

//connect to the database

$connection = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_Name);

if(mysqli_error($connection)){
    die(mysqli_error($connection));
}
?>