<?php
session_start();
define('ROOT_URL','http://localhost/paws_&_found/');

define('DB_HOST', 'localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_Name','blog_project1');

?>