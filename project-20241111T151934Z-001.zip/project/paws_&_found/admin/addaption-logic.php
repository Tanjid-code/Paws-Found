<?php 
session_start();
require 'config/database.php';

if(isset($_POST['submit'])){
    $firstname = filter_var($_POST['firstname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $lastname = filter_var($_POST['lastname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    // Remove this if `username` is not needed, or ensure form has `name="username"`
    $username = isset($_POST['username']) ? filter_var($_POST['username'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : '';
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $address = filter_var($_POST['address'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $phone = filter_var($_POST['phone'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    if(!$firstname){
        $_SESSION['add-adaptation'] = "Please enter your First Name";
    } elseif(!$lastname){
        $_SESSION['add-adaptation'] = "Please enter your Last Name";
    } elseif(!$email){
        $_SESSION['add-adaptation'] = "Please enter a valid email";
    } elseif(!$address){
        $_SESSION['add-adaptation'] = "Please enter a valid address";
    } elseif(!$phone){
        $_SESSION['add-adaptation'] = "Please enter a valid phone";
    }

    if(isset($_SESSION['add-adaptation'])){
        $_SESSION['add-adaptation-data'] = $_POST;
        header('location: ' . ROOT_URL . 'admin/addaption.php');
        exit();
    } else {
        // If `username` column does not exist, remove it from the query
        $insert_user_query = "INSERT INTO adaptation (firstname, lastname, email, address, phone) VALUES ('$firstname', '$lastname', '$email', '$address', '$phone')";
        
        $insert_user_result = mysqli_query($connection, $insert_user_query);

        if($insert_user_result !== false){
            $_SESSION['add-user-success'] = "Your Adaptation Form was added successfully";
            header('location: ' . ROOT_URL . 'admin/index.php');
            exit();
        }
    }
} else {
    header('location: ' . ROOT_URL . 'admin/add-addaption.php');
    exit();
}
?>
