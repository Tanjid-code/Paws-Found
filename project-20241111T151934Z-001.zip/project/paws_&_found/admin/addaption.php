<?php 
include 'partials/header.php';

$firstname = $_SESSION['add-adaptation-data']['firstname'] ?? null;
$lastname = $_SESSION['add-adaptation-data']['lastname'] ?? null;
$email = $_SESSION['add-adaptation-data']['email'] ?? null;
$address = $_SESSION['add-adaptation-data']['address'] ?? null;
$phoneNumber = $_SESSION['add-adaptation-data']['phone'] ?? null;
$userrole = $_SESSION['add-adaptation-data']['user-role'] ?? null;

//delete session data
unset($_SESSION['add-adaptation-data']);
?>
    
    <section class="form-section">
    <div class="container form-section-container">
        <h2>Addaptation Form</h2>
        <?php if(isset($_SESSION['add-adaptation'])) : ?>
            <div class="alert-message error">
                <p>
                    <?= $_SESSION['add-adaptation'];
                    unset($_SESSION['add-adaptation']);
                    ?>
                </p>
            </div>
        <?php endif ?>

        <form action="<?= ROOT_URL ?>admin/addaption-logic.php" enctype="multipart/form-data" method="POST">
            <input type="text" name="firstname" value="<?= $firstname ?>" placeholder="First Name">

            <input type="text" name="lastname" value="<?= $lastname ?>" placeholder="Last Nmae">

            <input type="email" name="email" value="<?= $email ?>" placeholder="Email">

            <input type="text" name="address" placeholder="Enter your address">


            <input type="text" name="phone" value="<?= $phoneNumber ?>" placeholder="phone number">


            <button type="submit" name="submit" class="btn">Submit</button>
        </form>
    </div>
    </section>

<?php 
include '../partials/footer.php';
?>