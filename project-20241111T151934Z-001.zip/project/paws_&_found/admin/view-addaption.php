<?php 
include 'partials/header.php';

//fetch users from database but not current user
$current_admin_id = $_SESSION['user-id'];
$query = "SELECT * FROM adaptation WHERE id = $current_admin_id";
$users = mysqli_query($connection, $query);
?>


    <!-- ################################ Dashbord ##############################  -->
    
    <section class="dashboard">

    <?php if(isset($_SESSION['add-adaptation-success'])) : ?>
                <div class="alert-message success container"> 
                  <p>
                <?= $_SESSION['add-adaptation-success'];
                unset($_SESSION['add-adaptation-success']); ?>
                </p>
               </div>
    <?php elseif(isset($_SESSION['edit-adaptation-success'])) : ?>
                <div class="alert-message success container"> 
                  <p>
                <?= $_SESSION['edit-adaptation-success'];
                unset($_SESSION['edit-adaptation-success']); ?>
                </p>
               </div>

     <?php elseif(isset($_SESSION['edit-adaptation'])) : ?>
                <div class="alert-message error container"> 
                  <p>
                <?= $_SESSION['edit-adaptation'];
                unset($_SESSION['edit-adaptation']); ?>
                </p>
               </div>

     <?php elseif(isset($_SESSION['delete-adaptation'])) : ?>
                <div class="alert-message error container"> 
                  <p>
                <?= $_SESSION['delete-adaptation'];
                unset($_SESSION['delete-adaptation']); ?>
                </p>
               </div>

      <?php elseif(isset($_SESSION['delete-adaptation-success'])) : ?>
                <div class="alert-message success container"> 
                  <p>
                <?= $_SESSION['delete-adaptation-success'];
                unset($_SESSION['delete-adaptation-success']); ?>
                </p>
               </div>
        
    <?php endif ?>

        <div class="container dashboard-container">
            <button id="show-sidebar-btn" class="sidebar-toggle"><i class="fa-solid fa-angle-right"></i></button>
            <button id="hide-sidebar-btn" class="sidebar-toggle"><i class="fa-solid fa-angle-left"></i></button>

            <aside>
                <ul>
                    <li>
                     <a href="./add-post.php">
                       <i class="fa-regular fa-newspaper"></i>
                       <h5>Add post</h5>
                     </a>
                    </li>


                    <li>
                        <a href="./index.php">
                        <i class="fa-regular fa-pen-to-square"></i>
                          <h5>Manage post</h5>
                        </a>
                    </li>

                    <?php if(isset($_SESSION['user_is_admin'])) : ?>



                    <li>
                        <a href="./add-user.php">
                          <i class="fa-solid fa-user"></i>
                          <h5>Add User</h5>
                        </a>
                    </li>

                    <li>
                        <a href="./manage-users.php" class="active">
                        <i class="fa-solid fa-user-pen"></i>
                          <h5>Manage User</h5>
                        </a>
                    </li>


                    <li>
                        <a href="./add-category.php">
                          <i class="fa-solid fa-layer-group"></i>
                          <h5>Add Category</h5>
                        </a>
                    </li>

                    <li>
                        <a href="./manage-categories.php">
                            <i class="fa-solid fa-pen"></i>
                          <h5>Manage Category</h5>
                        </a>
                    </li>

                    <?php endif ?>
                </ul>
            </aside>

            <main>
                <h2>Adaptation Request</h2>
                <?php if(mysqli_num_rows($users) > 0) : ?>
                <table>
                    <thead>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Phone</th>
                    </thead>
                    <tbody>
                        <?php while($user = mysqli_fetch_assoc($users)) : ?>
                        <tr>
                            <td><?= "{$user['firstname']} {$user['lastname']}" ?></td>
                            <td><?= $user['email'] ?></td>
                            <td><?= $user['address'] ?></td>
                            <td><?= $user['phone'] ?></td>                   
                        </tr>

                        <?php endwhile ?>
                    </tbody>
                </table>

                <?php else : ?>
                  <div class="alert-message error "><?= "No Request found" ?></div>
                <?php endif ?>
            </main>
        </div>
    </section>


<!-- ################################### footer ##########################################  -->

<?php 
include '../partials/footer.php';
?>




