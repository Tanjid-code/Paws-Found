



<footer>
        <div class="footer-socials">
            <a href="https//youtube.com" target="_blank"><i class="fa-brands fa-youtube"></i></a>
            <a href="https//facebook.com" target="_blank"><i class="fa-brands fa-facebook"></i></a>
            <a href="https//instagram.com" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="https//linkedin.com" target="_blank"><i class="fa-brands fa-linkedin"></i></i></a>
            <a href="https//twitter.com" target="_blank"><i class="fa-brands fa-twitter"></i></a>
        </div>



        <div class="container footer-container">
            <article>
                <h4>categories</h4>
                <ul>
                    <li><a href="">Art</a></li>
                    <li><a href="">wild Life</a></li>
                    <li><a href="">Travel</a></li>
                    <li><a href="">Music</a></li>
                    <li><a href="">Science & Technology</a></li>
                    <li><a href="">Food</a></li>
                </ul>
            </article>


            <article>
                <h4>Support</h4>
                <ul>
                    <li><a href="">Online Support</a></li>
                    <li><a href="">Call Numbers</a></li>
                    <li><a href="">Emails</a></li>
                    <li><a href="">Social Support</a></li>
                    <li><a href="">Location</a></li>
                </ul>
            </article>

            <article>
                <h4>Blog</h4>
                <ul>
                    <li><a href="">Safety</a></li>
                    <li><a href="">Repair</a></li>
                    <li><a href="">Recent</a></li>
                    <li><a href="">Popular</a></li>
                    <li><a href="">Categories</a></li>
                </ul>
            </article>


            <article>
                <h4>permalinks</h4>
                <ul>
                    <li><a href="">Home</a></li>
                    <li><a href="">Blog</a></li>
                    <li><a href="">About</a></li>
                    <li><a href="">Services</a></li>
                    <li><a href="">Contact</a></li>
                </ul>
            </article>
        </div>

        <div class="footer-copyright">
            <small>Copyright &copy; 2024 Pet Portal</small>
        </div>
    </footer>

    <script src="<?= ROOT_URL ?>js/main.js"></script>
</body>
</html>