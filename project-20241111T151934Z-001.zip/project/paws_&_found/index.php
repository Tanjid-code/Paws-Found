<?php
include './partials/header.php';
?>

<section class="web-header">
    <div class="box-info-left">
      <h1>We Need Your Help</h1>
      <h2>Adopt Us</h2>
      <p>The pet adoption website is a dynamic online platform that connects potential pet adopters with animals in need of a loving home. It offers a user-friendly interface where users can browse profiles of adoptable pets, complete with photos, descriptions, and adoption requirements.</p>
      <a href="./contact.php" class="btn">Contact Us</a>
    </div>
  
    <div class="box-info-right">
      <div class="adpot-image">
          <img src="./static-images/p1.png" alt="">
      </div>
    </div>
  </section>



  <section class="pet-card-section">
    <div class="container">
      <div class="process-title">
        <h2>Process to adopt a pet</h2>
        <p>Adopting a pet involves several steps to ensure the pet and adopter are well-matched.</p>
      </div>

      <div class="cards">
        <div class="card card1">
          <i class="fa-solid fa-shield-dog"></i>
          <h3>Browse our pets</h3>
          <p>Start by browsing through the available pets on our platform. Each pet listing includes details about their breed, age, temperament, and any special care needs. Take your time to explore different options and find a pet that fits your lifestyle and preferences.</p>
        </div>

        <div class="card card2">
          <i class="fa-solid fa-file"></i>
          <h3>Meet the Pet</h3>
          <p>Once you’ve found a pet you’re interested in, schedule a meeting to meet them in person. This is a crucial step to assess how you and the pet interact. During the meeting, observe the pet’s behavior, get to know their personality.</p>
        </div>

        <div class="card card3">
          <i class="fa-solid fa-user"></i>
          <h3>Pet Adaptation</h3>
          <p>If you feel the pet is a good match, submit an adoption inquiry form. This will include your personal details, living situation, and any experience you have with pets. The form helps us ensure that you’re fully prepared to adopt and care for the pet.</p>
        </div>


        <div class="card card4">
          <i class="fa-solid fa-house"></i>
          <h3>Get Your Pets</h3>
          <p>Bringing a new pet into your home involves preparing a safe space, establishing a routine, and building trust. Start by pet-proofing your home and creating a comfortable area for them. Introduce your pet slowly to avoid overwhelming them.</p>
        </div>
      </div>
    </div>
  </section>




  <section class="find-your-favorite-pet">
    <div class="container">
      <div class="find">
        <h2>Find Your Favorite Pets</h2>
        <div class="button-section">
          <a href="./blog2.php" class="btn">Find</a>
          <a href="./signin.php" class="btn">Fill Adaption Form</a>
        </div>
      </div>
  
    </div>
  </section>



<?php
include './partials/footer.php';
?>

<script src="./js/main.js"></script>
</body>
</html>
