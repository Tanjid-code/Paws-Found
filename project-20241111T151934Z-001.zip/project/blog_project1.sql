-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2024 at 11:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog_project1`
--

-- --------------------------------------------------------

--
-- Table structure for table `adaptation`
--

CREATE TABLE `adaptation` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adaptation`
--

INSERT INTO `adaptation` (`id`, `firstname`, `lastname`, `email`, `address`, `phone`) VALUES
(1, 'jone', 'reza', 'imranreza.cse@gmail.com', 'fgdsg', '017xxxxxxxx'),
(2, 'imran', 'reza', 'imranreza.cse@gmail.com', 'fgdsg', '017xxxxxxxx');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `description`) VALUES
(4, 'Uncategorized', 'all uncategorized post are under this section'),
(16, 'Dog', 'Dogs category'),
(17, 'Cats', 'Cats category'),
(18, 'Birds', 'Birds category'),
(19, 'Food', 'pets food'),
(20, 'Care', 'How to care a pets'),
(21, 'Problems', 'pets Problems\r\n'),
(22, 'Benefits', 'all Benefits'),
(23, 'Tips', 'all Tips');

-- --------------------------------------------------------

--
-- Table structure for table `pets`
--

CREATE TABLE `pets` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `author_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pets`
--

INSERT INTO `pets` (`id`, `title`, `body`, `thumbnail`, `date_time`, `category_id`, `author_id`) VALUES
(4, 'Dogi', 'dog', '1731201447_cat-6946505_640.jpg', '2024-11-10 01:17:27', 16, 1),
(5, 'cats', 'cats', '1731201683cat-2068462_1280.jpg', '2024-11-10 01:18:31', 17, 1),
(6, 'Dog', 'dog', '1731201582_australian-shepherd-3237735_640.jpg', '2024-11-10 01:19:42', 16, 1),
(7, 'Dog', 'dog', '1731201608_dog-4988985_640.jpg', '2024-11-10 01:20:08', 16, 1),
(8, 'cat', 'cats', '1731201743_simba-8618301_1280.jpg', '2024-11-10 01:22:23', 17, 13),
(9, 'pegion', 'pegion', '1731201837_rock-dove-4884627_640.jpg', '2024-11-10 01:23:57', 18, 14),
(10, 'pigeon', 'birds', '1731201867_mandarin-ducks-8525827_640.jpg', '2024-11-10 01:24:27', 18, 14),
(11, 'Thomas', 'Highly breeded', '1731221867_cat-6762936_640.jpg', '2024-11-10 06:57:47', 4, 14);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `category_id` int(11) UNSIGNED DEFAULT NULL,
  `author_id` int(11) UNSIGNED NOT NULL,
  `is_featured` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `thumbnail`, `date_time`, `category_id`, `author_id`, `is_featured`) VALUES
(32, 'he Benefits of Adopting Pets from Shelters', 'Adopting a pet from a shelter not only provides a loving home for an animal in need but also offers several benefits for pet owners. Shelter animals are often well-socialized and may already be trained, saving time and effort in adjusting to a new pet. Adopting from a shelter also supports humane organizations and helps combat the overpopulation crisis in animals, as each adoption opens up space for more animals to receive care. Moreover, adopting from shelters is often more affordable than purchasing pets from breeders, making it a financially and ethically responsible choice for prospective pet owners.', '1731200663_evening-8429871_640.jpg', '2024-11-10 01:04:23', 22, 1, 1),
(33, ' Essential Tips for Training a New Puppy', 'Bringing a new puppy home can be an exciting, rewarding experience, but it also requires patience and dedication, especially when it comes to training. Start with basic commands like &quot;sit,&quot; &quot;stay,&quot; and &quot;come,&quot; as these lay the foundation for good behavior. Housebreaking should be consistent; take your puppy outside frequently, particularly after meals and naps, and reward them when they go in the right place. Socializing your puppy with people, other pets, and different environments helps reduce anxiety and build confidence. Remember, positive reinforcement is key &ndash; treats, praise, and affection go a long way in making training an enjoyable process for both you and your puppy.', '1731200759_dog-5753302_640.jpg', '2024-11-10 01:05:59', 23, 1, 0),
(34, 'Keeping Your Indoor Cat Stimulated and Happy', 'Indoor cats can live long, healthy lives, but they need enrichment to stay mentally and physically stimulated. Toys that mimic hunting behaviors, such as feather wands and laser pointers, help satisfy their instincts. Consider a cat tree or window perch to give them a vantage point and sense of exploration. Interactive feeders and puzzle toys can make mealtime engaging and challenging. Regular play sessions not only keep your cat happy but also strengthen your bond. By providing engaging activities, you can ensure your indoor cat stays happy, healthy, and entertained.', '1731200989_beach-5064674_640.jpg', '2024-11-10 01:09:49', 23, 1, 1),
(35, 'Choosing the Right Pet for Apartment Living', 'Not every pet is suitable for small apartments, so it&#039;s crucial to consider space limitations when choosing a companion animal. Cats, small dogs, rabbits, and some birds can adapt well to apartment living. Low-energy dog breeds, such as French Bulldogs and Dachshunds, may also be ideal choices. Fish tanks, reptile enclosures, or small rodents like hamsters take up minimal space and can be great pets for those with limited room. Before bringing a pet home, check your building&rsquo;s pet policies, and consider how much time and attention you can dedicate to meeting their needs in a confined space.\r\n\r\n', '1731201065_D1-Tips-for-the-First-30-Da-ys-of-Dog-Adoption.jpg', '2024-11-10 01:11:05', 23, 13, 0),
(36, ' Recognizing Common Health Issues in Dogs', 'Understanding the warning signs of common health issues in dogs can make a huge difference in their quality of life. Some ailments to watch for include skin allergies, dental disease, obesity, and arthritis. Symptoms like excessive scratching, bad breath, changes in appetite, or limping can indicate health issues. Regular check-ups with your veterinarian can catch problems early and help prevent more severe issues. By staying vigilant about your dog&rsquo;s health and providing preventive care, you can keep your pet comfortable and happy as they age.', '1731201106_premium_photo-1664095348054-23e772addfdf.jpeg', '2024-11-10 01:11:46', 4, 13, 0),
(37, 'How to Bond with Your New Cat', 'Cats can be independent, but creating a strong bond with them is possible and rewarding. Start by providing a calm, quiet environment where they can feel safe. Speak in a gentle tone and let your cat approach you at their own pace. Use treats and interactive toys to make positive associations with your presence. Grooming sessions, gentle petting, and respecting your cat&rsquo;s boundaries help build trust. With time and patience, your cat will see you as a source of comfort and security, strengthening the bond between you.', '1731201145_simba-8618301_1280.jpg', '2024-11-10 01:12:25', 17, 13, 0),
(38, ' Preparing Your Home for a New Pet', 'Bringing a new pet home involves making your space pet-friendly and safe. Set up a designated area with essentials like a bed, food, and water bowls, and litter or training pads for young animals. Remove any hazardous items, including toxic plants, small objects, and exposed cords that curious pets may chew on. A scratching post for cats or a playpen for dogs can help keep pets occupied and prevent unwanted behaviors. Preparing your home not only eases the transition but also creates a welcoming, safe space for your new furry friend.', '1731201242_premium_photo-1664095348054-23e772addfdf.jpeg', '2024-11-10 01:14:02', 23, 1, 1),
(39, 'raveling with Your Pet: Tips for a Smooth Journey', 'Whether you&rsquo;re hitting the road or taking a flight, traveling with pets requires careful planning. Start by ensuring your pet is comfortable in a carrier or restraint that allows them to feel secure. Pack their essentials, including food, water, medications, and familiar items like toys or blankets. If flying, check with the airline for pet policies and make necessary arrangements in advance. For car trips, take regular breaks for exercise and bathroom needs. With proper preparation, you can make traveling less stressful for both you and your pet, making for a pleasant journey.', '1731202170_beach-5064674_640.jpg', '2024-11-10 01:29:30', 22, 1, 1),
(40, ' Fun DIY Toys for Cats and Dogs', 'Making DIY toys for your pets can be a fun, affordable way to keep them entertained. For dogs, try making a tug toy by braiding strips of old fabric. Cats often enjoy simple toys like paper bags, cardboard boxes, and feather wands that mimic prey. You can create treat-dispensing toys by cutting holes in a cardboard tube and filling it with kibble or treats. These DIY toys not only save money but also allow you to customize play experiences that cater to your pet&rsquo;s unique preferences and personality.\r\n\r\n', '1731202740_how-you-can-help_adoptions-tips_main-image-dog.jpg', '2024-11-10 01:39:00', 23, 1, 1),
(42, 'Adopt', 'German Shepherd', '1731221960_dog-4988985_640.jpg', '2024-11-10 06:59:20', 16, 14, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `email`, `password`, `avatar`, `is_admin`) VALUES
(1, 'imran', 'reza', 'imranreza', 'imranreza@gmail.com', '$2y$10$c3KGf/oIQjumfrTumW2jruMU0426WXUMy3Jyjjb/0mSR2L6Q4ckAK', '1714647309c1.jpg', 1),
(13, 'Tanjid', 'Hasan', 'tanjid', 'tanjid@gmail.com', '$2y$10$h0tmMGIHr3674PDIu2pC3uRnar9VBy5JyMI/Gyhl/w6WjhLAFMCIu', '1731200294cat-551554_1920.jpg', 1),
(14, 'A.', 'kaium', 'kaium', 'kaium@gmail.com', '$2y$10$qvF5NU836KV2XAViuv3Nqu.C71X1mfaOWQkYCbKTLOOCuT/Gf8qt6', '1731200354cat-8540772_640.jpg', 0),
(15, 'Md', 'Shahin', 'shahin', 'shahin@gmail.com', '$2y$10$mEOtLpnAaG5ayGKeIBwyzukCmQXpzGOLWz7K6cPgQ990HqA2oDb02', '1731200409dog-4988985_640.jpg', 1),
(16, 'Md', 'reza', 'reza', 'reza@gmail.com', '$2y$10$C32VzpvJi8a0N45zaQjP3eV84DczR.ospBNKc8Ml1X/nvfRxwJ0XO', '1731200505australian-shepherd-3237735_640.jpg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adaptation`
--
ALTER TABLE `adaptation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pets_id` (`category_id`),
  ADD KEY `fk_pets2_id` (`author_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_blog_category` (`category_id`),
  ADD KEY `FK_blog_author` (`author_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adaptation`
--
ALTER TABLE `adaptation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `pets`
--
ALTER TABLE `pets`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pets`
--
ALTER TABLE `pets`
  ADD CONSTRAINT `fk_pets2_id` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_pets_id` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `FK_blog_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_blog_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
